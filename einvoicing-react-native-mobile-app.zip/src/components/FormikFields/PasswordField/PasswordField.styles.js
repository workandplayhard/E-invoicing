import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  iconWrapper: {},
  icon: {
    width: 24,
    height: 24,
  },
});
