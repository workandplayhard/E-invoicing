import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  button: {
    position: 'absolute',
    bottom: 30,
    right: 30,
  },
  icon: {
    width: 76,
    height: 76,
  },
});
