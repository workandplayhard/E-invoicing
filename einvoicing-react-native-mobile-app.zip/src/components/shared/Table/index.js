export { default as Table } from './Table';
