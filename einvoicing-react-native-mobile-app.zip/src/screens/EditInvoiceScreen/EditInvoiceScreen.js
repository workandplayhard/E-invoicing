import React from 'react';

import styles from './EditInvoiceScreen.styles';

const EditInvoiceScreen = () => <></>;

export default React.memo(EditInvoiceScreen);
