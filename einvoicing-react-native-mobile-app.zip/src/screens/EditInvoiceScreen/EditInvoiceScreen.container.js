import React from 'react';

import EditInvoiceScreen from './EditInvoiceScreen';

const EditInvoiceScreenContainer = () => {
  return <EditInvoiceScreen />;
};

export default React.memo(EditInvoiceScreenContainer);
