export const getScreenTitleByInvoiceType = invoiceType => 'فاتورة نقدية';
