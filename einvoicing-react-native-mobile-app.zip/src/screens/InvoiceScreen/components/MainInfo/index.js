export { default as MainInfo } from './MainInfo';
