export { default as ProductsInfo } from './ProductsInfo';
