export { default as TotalsInfo } from './TotalsInfo';
