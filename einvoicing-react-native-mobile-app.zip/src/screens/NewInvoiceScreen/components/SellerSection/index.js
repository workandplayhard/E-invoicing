export { default as SellerSection } from './SellerSection';
